/**
 * Campus Complaint Portal (CCP) - Login Validation & Admin Authentication
 */

document.getElementById("loginForm")?.addEventListener("submit", function (e) {
    e.preventDefault();

    const emailInput = document.getElementById("loginEmail");
    const passInput = document.getElementById("loginPassword");
    const msg = document.getElementById("loginMsg");

    const email = emailInput ? emailInput.value.trim().toLowerCase() : "";
    const pass = passInput ? passInput.value : "";

    // Clear previous invalid states
    [emailInput, passInput].forEach(inp => {
        if (inp) inp.classList.remove("is-invalid");
    });
    msg.innerHTML = "";

    function triggerLoginError(title, text, inputEl) {
        if (inputEl) {
            inputEl.classList.add("is-invalid");
            inputEl.focus();
        }
        msg.innerHTML = `
            <div class="alert alert-danger p-2 mb-0 mt-2 small" role="alert">
                <strong>${title}:</strong> ${text}
            </div>
        `;
        alert(`${title}\n\n${text}`);
    }

    // 1. All fields required validation
    if (!email || !pass) {
        const firstEmpty = !email ? emailInput : passInput;
        triggerLoginError(
            "Login Validation: Required Fields",
            "Please enter both email and password.",
            firstEmpty
        );
        return;
    }

    // 2. Email pattern validation
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        triggerLoginError(
            "Login Validation: Email Pattern",
            "Please enter a valid email address format (e.g., admin@ccp.local).",
            emailInput
        );
        return;
    }

    // 3. Password length validation
    if (pass.length < 4) {
        triggerLoginError(
            "Login Validation: Password Length",
            "Password must be at least 4 characters long.",
            passInput
        );
        return;
    }

    // 4. Admin Authentication Check
    if (email === "admin@ccp.local" && pass === "admin123") {
        sessionStorage.setItem("ccp_admin", "true");
        msg.innerHTML = `<div class="alert alert-success p-2 mb-0 mt-2 small">Admin authenticated! Redirecting to Admin Dashboard...</div>`;
        alert("Admin Authentication Successful!\n\nWelcome Administrator. Redirecting to Admin Dashboard...");
        setTimeout(() => {
            location.href = "admin.html";
        }, 600);
        return;
    }

    // 5. Student User Authentication Check
    const user = CCP.getUsers().find(u => u.email && u.email.toLowerCase() === email && u.password === pass);
    if (user) {
        sessionStorage.setItem("ccp_user", JSON.stringify(user));
        msg.innerHTML = `<div class="alert alert-success p-2 mb-0 mt-2 small">Login successful! Redirecting to Dashboard...</div>`;
        alert("Login Successful!\n\nWelcome back! Redirecting to Student Dashboard...");
        setTimeout(() => {
            location.href = "dashboard.html";
        }, 600);
        return;
    }

    // 6. Invalid credentials validation
    triggerLoginError(
        "Authentication Error: Invalid Credentials",
        "Invalid email or password. For demo admin use:\nEmail: admin@ccp.local\nPassword: admin123",
        emailInput
    );
});
